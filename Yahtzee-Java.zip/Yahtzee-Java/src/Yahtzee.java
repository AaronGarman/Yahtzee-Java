public class Yahtzee {
    public static void main(String[] args)  // main method to run game
    {
        Board board = new Board();
    }
}





